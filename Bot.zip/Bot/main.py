import logging
import json
from urllib.parse import unquote
from telegram import Update
from telegram.ext import Application, CommandHandler, ContextTypes

# Configure logging
logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s', level=logging.INFO)

# Replace with your bot token
TOKEN = '7838578376:AAFqDPRJxBQaIvUedD3VaCpKbQ9BUSWF4ws'

async def convert(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if context.args:
        input_data = " ".join(context.args)  # Get input after the command
        logging.info("Received message: %s", input_data)

        # Extract the URL part from the input
        try:
            # Remove 'https://telegram.blum.codes/#tgWebAppData=' part if it exists
            if input_data.startswith("https://telegram.blum.codes/#tgWebAppData="):
                input_data = input_data.split('=')[1]
            # Decode the URL
            decoded_url = unquote(input_data)
            logging.info("Decoded URL: %s", decoded_url)

            # Split the query parameters
            params = decoded_url.split('&')
            output_data = '&'.join(params)

            await update.message.reply_text(f"Output: {output_data}")
        except Exception as e:
            logging.error("Error occurred: %s", str(e))
            await update.message.reply_text(f"Error: {str(e)}")
    else:
        await update.message.reply_text("Please provide the URL-encoded data after the command.")

def main():
    app = Application.builder().token(TOKEN).build()

    app.add_handler(CommandHandler("convert", convert))

    # Run the bot until the user presses Ctrl-C
    app.run_polling()

if __name__ == '__main__':
    main()
